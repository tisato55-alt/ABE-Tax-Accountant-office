
import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Services from './components/Services';
import Strengths from './components/Strengths';
import Process from './components/Process';
import Faq from './components/Faq';
import Contact from './components/Contact';
import Footer from './components/Footer';

const App: React.FC = () => {
  return (
    <div className="text-gray-800 font-sans">
      <Header />
      <main>
        <Hero />
        <About />
        <Services />
        <Strengths />
        <Process />
        <Faq />
        <Contact />
      </main>
      <Footer />
    </div>
  );
};

export default App;
