
import React from 'react';
import type { Strength } from '../types';
import ChatAlt2Icon from './icons/ChatAlt2Icon';
import TrendingUpIcon from './icons/TrendingUpIcon';
import ShieldCheckIcon from './icons/ShieldCheckIcon';

const strengths: Strength[] = [
  {
    icon: ChatAlt2Icon,
    title: '親身なコミュニケーション',
    description: '専門用語を避け、分かりやすい言葉で丁寧にご説明します。お客様との対話を重視し、何でも気軽に相談できる関係性を築きます。',
  },
  {
    icon: TrendingUpIcon,
    title: '豊富な経験と実績',
    description: '税務署での35年間に及ぶキャリア（個人12年・法人23年）で、多岐にわたる業種の申告・決算・調査に従事。長年の経験で蓄積した確かな審美眼とノウハウを駆使し、経営の安定と成長を支える最適な一手をご提案します。',
  },
  {
    icon: ShieldCheckIcon,
    title: 'ITを活用した効率化',
    description: 'クラウド会計ソフトの導入支援などを通じて、お客様の経理業務の効率化をサポート。スピーディで正確なサービスを提供します。',
  },
];

const StrengthItem: React.FC<{ strength: Strength }> = ({ strength }) => (
    <div className="flex items-start space-x-4">
        <div className="flex-shrink-0">
            <div className="flex items-center justify-center h-12 w-12 rounded-full bg-primary-100 text-primary-600">
                <strength.icon className="h-6 w-6" />
            </div>
        </div>
        <div>
            <h3 className="text-lg font-bold text-gray-900">{strength.title}</h3>
            <p className="mt-1 text-gray-600">{strength.description}</p>
        </div>
    </div>
);

const Strengths: React.FC = () => {
  return (
    <section id="strengths" className="py-20 bg-white/90 backdrop-blur-sm">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-3 lg:gap-8 lg:items-center">
            <div className="lg:col-span-1">
                <h2 className="text-3xl font-bold text-gray-900 tracking-tight sm:text-4xl">
                    棈松克文税理士事務所が選ばれる理由
                </h2>
                <p className="mt-4 text-lg text-gray-600">
                    お客様のビジネスに寄り添い、共に成長するパートナーとして、わたしは3つの強みをお約束します。
                </p>
                 <div className="mt-4 w-24 h-1 bg-primary-600 rounded"></div>
            </div>
            <div className="mt-12 lg:mt-0 lg:col-span-2">
                <dl className="space-y-10">
                    {strengths.map((strength, index) => (
                        <StrengthItem key={index} strength={strength} />
                    ))}
                </dl>
            </div>
        </div>
      </div>
    </section>
  );
};

export default Strengths;