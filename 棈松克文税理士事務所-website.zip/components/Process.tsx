
import React from 'react';
import type { ProcessStep } from '../types';

const steps: ProcessStep[] = [
  {
    step: '01',
    title: 'お問い合わせ',
    description: 'まずはお電話またはお問い合わせフォームから、お気軽にご連絡ください。簡単なヒアリングをさせていただきます。',
  },
  {
    step: '02',
    title: '初回無料相談',
    description: 'お客様の状況や課題を詳しくお伺いします。当事務所のサービスについても丁寧にご説明いたします。',
  },
  {
    step: '03',
    title: 'ご提案・お見積もり',
    description: 'ヒアリング内容に基づき、お客様に最適なサービスプランとお見積もりをご提案させていただきます。',
  },
  {
    step: '04',
    title: 'ご契約・業務開始',
    description: 'ご提案内容にご納得いただけましたら、契約を締結し、速やかに業務を開始いたします。',
  },
];

const Process: React.FC = () => {
  return (
    <section id="process" className="py-20 bg-gray-50/90 backdrop-blur-sm">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900">ご契約までの流れ</h2>
          <p className="mt-4 text-lg text-gray-600">簡単4ステップで、スムーズにサービスを開始できます。</p>
          <div className="mt-4 w-24 h-1 bg-primary-600 mx-auto rounded"></div>
        </div>
        <div className="relative">
          <div className="hidden md:block absolute top-10 bottom-10 left-1/2 w-0.5 bg-primary-200"></div>
          <div className="space-y-12 md:space-y-0">
            {steps.map((item, index) => (
              <div key={index} className="flex flex-col md:flex-row items-center">
                <div className={`flex-1 md:text-right ${index % 2 === 0 ? 'md:pr-8' : 'md:pl-8 md:order-2'}`}>
                  <h3 className="text-2xl font-bold text-primary-700">{item.title}</h3>
                  <p className="mt-2 text-gray-600">{item.description}</p>
                </div>
                <div className="flex-shrink-0 my-4 md:my-0 md:order-1">
                  <div className="w-20 h-20 bg-primary-600 rounded-full flex items-center justify-center text-white text-3xl font-bold shadow-lg z-10 relative">
                    {item.step}
                  </div>
                </div>
                <div className="flex-1"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Process;
