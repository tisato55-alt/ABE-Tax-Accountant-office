
import React from 'react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className="bg-primary-900/95 text-white">
      <div className="container mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <p>&copy; {currentYear} 棈松克文税理士事務所. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
