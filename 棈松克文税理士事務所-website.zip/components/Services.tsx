
import React from 'react';
import type { Service } from '../types';
import BriefcaseIcon from './icons/BriefcaseIcon';
import DocumentReportIcon from './icons/DocumentReportIcon';
import UserGroupIcon from './icons/UserGroupIcon';
import ChartBarIcon from './icons/ChartBarIcon';
import LightBulbIcon from './icons/LightBulbIcon';
import HomeIcon from './icons/HomeIcon';

const services: Service[] = [
  {
    icon: BriefcaseIcon,
    title: '税務顧問',
    description: '月次決算、税務相談、節税対策など、継続的なサポートで経営を安定させます。',
  },
  {
    icon: DocumentReportIcon,
    title: '確定申告',
    description: '個人事業主・法人様の面倒な確定申告を、迅速かつ正確に代行いたします。',
  },
  {
    icon: UserGroupIcon,
    title: '相続・事業承継',
    description: '複雑な相続税の申告や、円滑な事業承継の計画立案をサポートします。',
  },
  {
    icon: LightBulbIcon,
    title: '創業支援',
    description: '会社設立の手続きから、資金調達、事業計画の策定までトータルで支援します。',
  },
  {
    icon: ChartBarIcon,
    title: '経営コンサルティング',
    description: '財務分析を通じて経営課題を抽出し、事業の成長をサポートする提案を行います。',
  },
  {
    icon: HomeIcon,
    title: '不動産税務',
    description: '不動産の売買、賃貸、相続に関わる税務問題を専門的に解決いたします。',
  },
];

const ServiceCard: React.FC<{ service: Service }> = ({ service }) => (
  <div className="bg-white p-8 rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300 flex flex-col items-center text-center">
    <div className="p-4 bg-primary-100 rounded-full mb-4">
       <service.icon className="w-10 h-10 text-primary-600" />
    </div>
    <h3 className="text-xl font-bold text-gray-900 mb-2">{service.title}</h3>
    <p className="text-gray-600">{service.description}</p>
  </div>
);


const Services: React.FC = () => {
  return (
    <section id="services" className="py-20 bg-gray-50/90 backdrop-blur-sm">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900">サービス内容</h2>
          <p className="mt-4 text-lg text-gray-600">お客様のニーズに合わせた多様なサービスをご提供します。</p>
          <div className="mt-4 w-24 h-1 bg-primary-600 mx-auto rounded"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <ServiceCard key={index} service={service} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
