
import React, { useState } from 'react';
import type { FaqItem } from '../types';

const faqData: FaqItem[] = [
  {
    question: '相談だけでも可能ですか？料金はかかりますか？',
    answer: 'はい、もちろん相談だけでも大歓迎です。初回の60分間は無料相談とさせていただいておりますので、まずはお気軽にお悩みをお聞かせください。',
  },
  {
    question: '税理士に依頼するメリットは何ですか？',
    answer: '専門家による正確な申告で税務リスクを軽減できるほか、節税対策や資金繰りのアドバイスなど、経営に役立つサポートを受けられます。また、面倒な経理業務から解放され、本業に集中できる時間が増えることも大きなメリットです。',
  },
  {
    question: '料金はどのように決まりますか？',
    answer: '料金は、お客様の事業規模、売上、訪問回数、ご依頼いただく業務内容などに応じて、個別にお見積もりさせていただきます。無料相談の際に、サービス内容と合わせて明確な料金をご提示しますのでご安心ください。',
  },
  {
    question: '対応エリアはどこまでですか？',
    answer: '主に熊本国税局管内（熊本、鹿児島、宮崎、大分）を中心に対応しておりますが、メールやZoomなどを活用することで全国のお客様に対応可能です。遠方の方もお気軽にご相談ください。',
  },
];

const FaqAccordionItem: React.FC<{ item: FaqItem; isOpen: boolean; onClick: () => void; }> = ({ item, isOpen, onClick }) => (
    <div className="border-b border-gray-200">
        <h2>
            <button
                type="button"
                className="flex justify-between items-center w-full py-5 font-medium text-left text-gray-700"
                onClick={onClick}
                aria-expanded={isOpen}
            >
                <span>{item.question}</span>
                <svg
                    className={`w-6 h-6 shrink-0 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`}
                    fill="currentColor"
                    viewBox="0 0 20 20"
                    xmlns="http://www.w3.org/2000/svg"
                >
                    <path
                        fillRule="evenodd"
                        d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                        clipRule="evenodd"
                    ></path>
                </svg>
            </button>
        </h2>
        <div className={`overflow-hidden transition-all duration-300 ease-in-out ${isOpen ? 'max-h-96' : 'max-h-0'}`}>
            <div className="py-5">
                <p className="text-gray-600 leading-relaxed">{item.answer}</p>
            </div>
        </div>
    </div>
);


const Faq: React.FC = () => {
    const [openIndex, setOpenIndex] = useState<number | null>(0);

    const handleToggle = (index: number) => {
        setOpenIndex(openIndex === index ? null : index);
    };

  return (
    <section id="faq" className="py-20 bg-white/90 backdrop-blur-sm">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900">よくあるご質問</h2>
          <p className="mt-4 text-lg text-gray-600">お客様から寄せられるご質問とその回答です。</p>
          <div className="mt-4 w-24 h-1 bg-primary-600 mx-auto rounded"></div>
        </div>
        <div className="max-w-3xl mx-auto">
            {faqData.map((item, index) => (
                <FaqAccordionItem 
                    key={index} 
                    item={item}
                    isOpen={openIndex === index}
                    onClick={() => handleToggle(index)}
                />
            ))}
        </div>
      </div>
    </section>
  );
};

export default Faq;