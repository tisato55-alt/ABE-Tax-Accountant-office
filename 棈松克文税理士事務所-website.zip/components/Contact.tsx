
import React, { useState } from 'react';

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [status, setStatus] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prevState => ({ ...prevState, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setStatus('送信中...');
    // In a real app, you would handle form submission here (e.g., API call)
    setTimeout(() => {
      setStatus('メッセージが送信されました。ありがとうございます。');
      setFormData({ name: '', email: '', message: '' });
    }, 1000);
  };
  
  return (
    <section id="contact" className="py-20 bg-gray-50/90 backdrop-blur-sm">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900">お問い合わせ</h2>
          <p className="mt-4 text-lg text-gray-600">ご相談、ご質問などお気軽にお問い合わせください。</p>
          <div className="mt-4 w-24 h-1 bg-primary-600 mx-auto rounded"></div>
        </div>
        <div className="flex flex-col lg:flex-row gap-12">
          <div className="lg:w-1/2 bg-white/80 p-8 rounded-lg shadow-lg">
            <h3 className="text-2xl font-bold mb-6 text-gray-800">お問い合わせフォーム</h3>
            <form onSubmit={handleSubmit}>
              <div className="mb-4">
                <label htmlFor="name" className="block text-gray-700 font-medium mb-2">お名前</label>
                <input type="text" id="name" name="name" value={formData.name} onChange={handleChange} required className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500" />
              </div>
              <div className="mb-4">
                <label htmlFor="email" className="block text-gray-700 font-medium mb-2">メールアドレス</label>
                <input type="email" id="email" name="email" value={formData.email} onChange={handleChange} required className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500" />
              </div>
              <div className="mb-6">
                <label htmlFor="message" className="block text-gray-700 font-medium mb-2">お問い合わせ内容</label>
                <textarea id="message" name="message" rows={5} value={formData.message} onChange={handleChange} required className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"></textarea>
              </div>
              <button type="submit" className="w-full bg-primary-600 text-white font-bold py-3 px-6 rounded-md hover:bg-primary-700 transition-colors duration-300">送信する</button>
              {status && <p className="mt-4 text-center text-gray-600">{status}</p>}
            </form>
          </div>
          <div className="lg:w-1/2">
            <div className="bg-white/80 p-8 rounded-lg shadow-lg h-full flex flex-col">
              <h3 className="text-2xl font-bold mb-6 text-gray-800">事務所情報</h3>
              <div className="space-y-4 text-gray-700">
                <p><strong>事務所名:</strong> 棈松克文税理士事務所</p>
                <p><strong>所在地:</strong> 〒867-0065　熊本県水俣市浜町2-3-8（2026.2.1以降）</p>
                <p><strong>電話番号:</strong> 080-8048-8154</p>
                <p><strong>営業時間:</strong> 平日 9:00〜17:00</p>
              </div>
               <div className="mt-6 flex-grow rounded-md overflow-hidden">
                  <iframe
                    className="w-full h-full"
                    src="https://maps.google.com/maps?q=%E7%86%8A%E6%9C%AC%E7%9C%8C%E6%B0%B4%E4%BF%A3%E5%B8%82%E6%B5%9C%E7%94%BA%EF%BC%92%E4%B8%81%E7%9B%AE%EF%BC%93%E2%88%92%EF%BC%98&t=&z=15&ie=UTF8&iwloc=&output=embed"
                    style={{ border: 0 }}
                    allowFullScreen={false}
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    title="事務所所在地マップ"
                  ></iframe>
               </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;