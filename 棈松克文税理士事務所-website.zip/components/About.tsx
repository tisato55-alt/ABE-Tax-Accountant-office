
import React from 'react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-white/90 backdrop-blur-sm">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900">事務所概要</h2>
          <p className="mt-4 text-lg text-gray-600">信頼と実績で、お客様のビジネスを未来へ導きます。</p>
          <div className="mt-4 w-24 h-1 bg-primary-600 mx-auto rounded"></div>
        </div>
        <div className="flex flex-col md:flex-row items-center gap-12">
          <div className="md:w-1/3">
            <img
              src="https://images.unsplash.com/photo-1560250097-0b93528c311a?q=80&w=800&auto=format&fit=crop"
              alt="代表税理士 棈松克文"
              className="rounded-full shadow-2xl mx-auto w-64 h-64 object-cover"
            />
          </div>
          <div className="md:w-2/3">
            <h3 className="text-2xl font-bold text-gray-800 mb-4">代表挨拶</h3>
            <p className="text-gray-700 leading-relaxed mb-4">
              棈松克文税理士事務所のウェブサイトへお越しいただき、誠にありがとうございます。代表税理士の棈松克文と申します。
            </p>
            <p className="text-gray-700 leading-relaxed mb-4">
              わたしは、中小企業の経営者様、個人事業主様、そしてこれから事業を始めようとされている方々の良きパートナーでありたいと考えております。目まぐるしく変化する経済環境と複雑な税法の中で、お客様が安心して事業に集中できるよう、専門的な知識と経験をもって全力でサポートいたします。
            </p>
            <p className="text-gray-700 leading-relaxed">
              お客様との対話を何よりも大切にし、一人ひとりの状況に合わせた最適なご提案を心がけております。どうぞお気軽にご相談ください。
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
