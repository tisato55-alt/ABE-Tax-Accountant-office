
import React from 'react';

const Hero: React.FC = () => {
  return (
    <section
      id="hero"
      className="relative text-white bg-cover bg-center"
      style={{ backgroundImage: "url('https://images.unsplash.com/photo-1521791136064-7986c2920216?q=80&w=2070&auto=format&fit=crop')" }}
    >
      <div className="absolute inset-0 bg-black bg-opacity-50"></div>
      <div className="relative container mx-auto px-4 sm:px-6 lg:px-8 py-32 md:py-48 text-center">
        <h1 className="text-4xl md:text-6xl font-extrabold leading-tight mb-4 tracking-tight drop-shadow-lg">
          企業の成長を税務・会計で支える
        </h1>
        <p className="text-lg md:text-xl max-w-3xl mx-auto mb-8 font-light drop-shadow-lg">
          わたしは、専門知識と経験を活かし、お客様一人ひとりに最適なソリューションを提供します。
        </p>
        <a
          href="#contact"
          className="inline-block bg-white text-primary-700 font-bold py-3 px-8 rounded-full text-lg hover:bg-gray-200 transition-all duration-300 transform hover:scale-105 shadow-lg"
        >
          初回無料相談はこちら
        </a>
      </div>
    </section>
  );
};

export default Hero;
